function startQuestion() {

    if (!("webkitSpeechRecognition" in window)) {
        alert("Speech recognition is not supported.");
        return;
    }

    const recognition =
        new webkitSpeechRecognition();

    recognition.lang = "en-IN";
    recognition.continuous = false;

    recognition.onresult = function(event) {

        const question =
            event.results[0][0].transcript;

        document.getElementById("question").innerText =
            "Question: " + question;

        answerQuestion(question);
    };

    recognition.start();
}

function answerQuestion(question) {

    const q = question.toLowerCase();

    let answer;

    if (q.includes("what is nlp")) {

        answer =
            "NLP stands for Natural Language Processing. " +
            "It helps computers understand human language.";

    }
    else if (q.includes("what is speech recognition")) {

        answer =
            "Speech recognition converts human speech into text.";

    }
    else if (q.includes("what is sentiment analysis")) {

        answer =
            "Sentiment analysis identifies emotions or opinions " +
            "expressed in text.";

    }
    else if (q.includes("what is text analysis")) {

        answer =
            "Text analysis extracts useful information and patterns " +
            "from written language.";

    }
    else {

        answer =
            "Sorry, I do not have an answer for that question.";

    }

    document.getElementById("answer").innerText = answer;

    const speech =
        new SpeechSynthesisUtterance(answer);

    speech.lang = "en-IN";

    speechSynthesis.speak(speech);
}